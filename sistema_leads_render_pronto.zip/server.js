
const express = require('express');
const fs = require('fs');
const path = require('path');
const cors = require('cors');
const app = express();

const PORT = process.env.PORT || 3000;
const leadsPath = path.join(__dirname, 'leads.json');

app.use(cors());
app.use(express.json());

app.post('/lead', (req, res) => {
  const novoLead = req.body;
  novoLead.data = new Date().toLocaleString('pt-BR');

  fs.readFile(leadsPath, 'utf8', (err, data) => {
    let leads = [];
    if (!err && data) {
      leads = JSON.parse(data);
    }
    leads.push(novoLead);

    fs.writeFile(leadsPath, JSON.stringify(leads, null, 2), err => {
      if (err) {
        return res.status(500).json({ error: 'Erro ao salvar o lead' });
      }
      res.status(200).json({ success: true });
    });
  });
});

app.get('/leads', (req, res) => {
  fs.readFile(leadsPath, 'utf8', (err, data) => {
    if (err) {
      return res.status(500).json({ error: 'Erro ao ler leads' });
    }
    res.json(JSON.parse(data));
  });
});

app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});
